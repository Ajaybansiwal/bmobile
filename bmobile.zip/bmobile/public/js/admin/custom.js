
$(document).ready(function(){
		$('.alert-success').delay(3000).fadeOut('slow');
		$('.alert-danger').delay(3000).fadeOut('slow');
	   $(".dropdown-toggle").click(function(){
    $(".user-menu").toggleClass("open");
});
});

$(function() {
  $("form[name='page']").validate({
    rules: {
	  title: { 
	   	required: true,
        number: false,
		maxlength: 255
	  },
    },
    // Specify validation error messages
    messages: {
      title: {
        required: "Please enter title of the page",
		number: "The title may only contain letters",
		maxlength: "Please enter must be 255 digits only"
      },
    },
    submitHandler: function(form) {
      form.submit();
    }
  });
});

$(function() {
  $("form[name='user']").validate({
    rules: {
	  name: { 
	   	required: true,
		maxlength: 255
	  },
	  email: { 
	   	required: true,
		email: true
	  },
	  password: { 
	   	required: true,
		minlength: 6
	  },
    },
    // Specify validation error messages
    messages: {
      name: {
        required: "Please enter name of the user",
		maxlength: "Please enter must be 255 digits only"
      },
	  email: {
        required: "Please select user email",
		email: "Please enter a valid email address"
      },
	  password: {
		   required: "Please enter password",
		   minlength: "Please enter at least 6 characters."
		  },
    },
    submitHandler: function(form) {
      form.submit();
    }
  });
});

function deletepage() {
	if( confirm("Are You Sure to delete page! You can't undo this once confirm") == true)
    {
        return true;
    }
    else
    {
        return false;
    }
	
}

function deleteuser() {
	if( confirm("Are You Sure to delete user! You can't undo this once confirm") == true)
    {
        return true;
    }
    else
    {
        return false;
    }
	
}
