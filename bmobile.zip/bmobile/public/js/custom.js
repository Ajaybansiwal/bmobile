
$(document).ready(function(){
     $('.menu-icon').click(function(){
        $('div.menu ul').slideToggle();
     });
    $('.search-icon').click(function(){
        $('div.search-content').slideToggle();
     });
    $('.search-close-btn').click(function(){
        $('div.search-content').slideToggle('hide');
     });
     /**************For more categories expand/Collepse*******/
     //Expand Categories on more click
     $('.more-card').click(function(){
        $('.rewards-credit').addClass('more-rewards');
         $('.rewards-credit').removeClass('singal-post');
         $(this).hide();
         $('.less-card').show();
     });
     //COllepse categories on less click
     $('.less-card').click(function(){
        $('.rewards-credit').not('.first-post').removeClass('more-rewards');
          $('.first-post').addClass('singal-post');
         $(this).hide();
         $('.more-card').show();
     });
     /**************For more categories expand/Collepse*******/
     /**************MOnthly spend and others****************/
     $('.more-filters-toggle').click(function(){
        $(this).next('.more-filters-content').slideToggle();
     });
     /**************MOnthly spend and others*************/
     /**************Category and filter in mobile****************/
     $('.card-group-toggel').click(function(){
         if($(this).parent('.categories-group').hasClass('card-expanded')){
             $('.card-group-toggel').parent('.categories-group').removeClass('card-expanded');
             $('body').removeClass('body-fix');
         }else{
             $('.card-group-toggel').parent('.categories-group').removeClass('card-expanded');
             $('body').addClass('body-fix');
             $(this).parent('.categories-group').addClass('card-expanded');
         }
     });
     /**************Category and filter in mobile*************/
});


$(window).scroll(function() {
  var footerHeight = $( ".footer" ).height();
  var documentHeight = $(document).height();
  var windowHeight = $(window).height();
  if ($(this).scrollTop() > 100){
        $('.card-panel__inner-wrapper').addClass('sticky');
        console.log((documentHeight - $(this).scrollTop()));
        if((documentHeight -$(this).scrollTop()) <= (windowHeight + footerHeight) + 75 ){
           $('.card-panel__inner-wrapper').removeClass('sticky');
           $('.card-panel__inner-wrapper').addClass('sticky-bottom');
        }else{
          $('.card-panel__inner-wrapper').removeClass('sticky-bottom');
          $('.card-panel__inner-wrapper').addClass('sticky');
        }
  }else{
    $('.card-panel__inner-wrapper').removeClass('sticky');
  }
});




$(window).scroll(function() { 
    if ($(this).scrollTop() < 250)
    {
        $(".compare-sticky-header").slideUp();   
    } 
    else
    {     
        $(".compare-sticky-header").slideDown();
    }
});
























