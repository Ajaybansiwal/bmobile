<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/', 'front\HomeController@index');
Route::get('/home', 'front\HomeController@index');
Route::get('/admin', 'admin\AdminController@index');
Route::resource('/admin/home','admin\HomeController');
Route::resource('/admin/role','admin\RoleController');
Route::get('/logout', 'admin\AdminController@logout');

Route::any('/{page?}',function(){
  return View::make('errors.503');
})->where('page','.*');
