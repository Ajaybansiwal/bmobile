<!doctype html>
<html>

@include('includes/front/head')

<body>

<div class="wrapper">

   @include('includes/front/header')
  
  
   <div class="featured">
  
    <div class="featured-img"><img src="{{ url('public/images/Home-Page.jpg') }}" alt=""></div>
    
    <div class="featured-content">
       <div class="featured-post"><a href="#"><h4>Products<span>you want</span></h4></a></div>
       <div class="featured-post"><a href="#"><h4>Pay Bills<span>services you need</span></h4></a></div>
       <div class="featured-post"><a href="#"><h4>promotions<span>for you</span></h4></a></div>
    </div>
  
  </div>
 
 
   @include('includes/front/footer')
 
 
  
  
</div>


</body>
</html>