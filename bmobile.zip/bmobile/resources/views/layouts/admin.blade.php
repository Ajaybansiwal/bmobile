<!DOCTYPE html>
<html>
@include('includes/admin/head')
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  @include('includes/admin/header')
  <!-- Left side column. contains the logo and sidebar -->
  @include('includes/admin/sidebar')

  <!-- Content Wrapper. Contains page content -->
  
  @yield('content')
  <!-- /.content-wrapper -->
  
  @include('includes/admin/footer')

  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
</body>
</html>
