@extends('layouts/admin')
@section('content')
<div class="content-wrapper">
    <section class="content">
        @if(Session::has('message'))
                    <div class="alert alert-success">
                        {{ Session::get('message') }}
                    </div>
            @endif
           @if (count($errors) > 0)
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif	
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New User</h3>
        </div>
        <div class="box-body">
          <div class="row">
           {{ Form::open(array('url' => 'admin/role','name' => 'user')) }}
            <div class="col-md-12">
              <div class="form-group">
              {{ Form::label('name', 'Name') }}<em class="error">&nbsp;*</em>
              {{ Form::text('name',null, array('class' => 'form-control')) }}
              </div>
              <div class="form-group">
              {{ Form::label('email', 'Email Id') }}<em class="error">&nbsp;*</em>
              {{ Form::text('email',null, array('class' => 'form-control')) }}
              </div>
              <div class="form-group">
              {{ Form::label('password', 'Password') }}<em class="error">&nbsp;*</em>
              {{ Form::password('password', array('class' => 'form-control')) }}
              </div>
              <div class="form-group">
              {{ Form::submit('Submit',array('name' => 'submit')) }}
              </div>
            </div>
           {{ Form::close() }}
          </div>
        </div>
      </div>
    </section>
</div>
  @endsection
  
  
