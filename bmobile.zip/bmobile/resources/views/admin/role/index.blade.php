@extends('layouts/admin')
@section('content')
<div class="content-wrapper">
    <section class="content">
        @if(Session::has('message'))
        <div class="alert alert-success">
            {{ Session::get('message') }}
        </div>
        @endif	
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Users</h3>
          @if(Auth::user()->role==1)
          <span style="margin-left:965px;"><a href="{{ url('admin/role/create') }}">Create New</a></span>
          @endif
        </div>
        <div class="box-body">
          <div class="row">
			<div class="col-xs-12">
          <div class="box">
            <!--<div class="box-header">
              <h3 class="box-title">Responsive Hover Table</h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  @if(Auth::user()->role==1)
                  <th>Action</th>
                  @endif
                </tr>
                @if($countuser==0)
                <tr>
                    <td colspan="4">No Record Found.</td>
                </tr> 
                @else
                @foreach($user as $users)
                <tr>
                  <td>{{ $users->name }}</td>
                  <td>{{ $users->email }}</td>
                  @if($users->role==1)
                  <td>Super Admin</td>
                  @else
                  <td>Admin</td>
                  @endif
                  @if(Auth::user()->role==1)
                  <td class="action">
                  <a href="{{ route('role.edit', $users->id) }}"><button class="btn btn-sm filter-submit margin-bottom">Edit</button></a>	&nbsp;
                  {!! Form::open(['method' => 'DELETE','route' => ['role.destroy', $users->id]]) !!}
                  <button onclick="return deleteuser(this.value)" class="btn btn-sm  filter-submit margin-bottom">Delete</button>
                  {!! Form::close() !!}
                  &nbsp;<!--<a href="{{ URL::to('role/' . $users->id) }}"><button class="btn btn-sm  filter-submit margin-bottom">Status</button></a>&nbsp;<a href="{{ URL::to('role/' . $users->id) }}"><button class="btn btn-sm  filter-submit margin-bottom">View</button></a>-->
                  </td>
                  @endif
                </tr>
                @endforeach 
                @endif
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>          
          </div>
        </div>
      </div>
    </section>
</div>
  @endsection
  
  
