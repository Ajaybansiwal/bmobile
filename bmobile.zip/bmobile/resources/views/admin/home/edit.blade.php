@extends('layouts/admin')
@section('content')
<div class="content-wrapper">
    <section class="content">
        @if(Session::has('message'))
                    <div class="alert alert-success">
                        {{ Session::get('message') }}
                    </div>
        @endif
        @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Page</h3>
        </div>
        <div class="box-body">
          <div class="row">
           {{ Form::model($page, array('route' => array('home.update', $page->id), 'method' => 'PUT','name' => 'page','files' => true)) }}
           {{ Form::hidden('oldimage', $page->image) }}
            <div class="col-md-12">
              <div class="form-group">
              {{ Form::label('title', 'Page Title') }}
              {{ Form::text('title',$page->title, array('class' => 'form-control')) }}
              </div>
              <div class="form-group">
              {{ Form::label('banner', 'Banner Image') }}
              {{ Form::file('image',array('class' => 'form-control')) }}
              <div style="margin-top:10px"><img src="http://localhost/bmobile/public/images/banner/{{ $page->image }}/{{ $page->image }}" height="46px" width="100px"></div>
              </div>
              <div class="form-group">
              {{ Form::label('content', 'Page Content') }}
              {{ Form::textarea('content',$page->content) }}
              </div>
              <div class="form-group">
              {{ Form::submit('Submit',array('name' => 'submit')) }}
              </div>
            </div>
           {{ Form::close() }}
          </div>
        </div>
      </div>
    </section>
</div>
  @endsection
  
  
