@extends('layouts/admin')
@section('content')
<div class="content-wrapper">
    <section class="content">
        @if(Session::has('message'))
                    <div class="alert alert-success">
                        {{ Session::get('message') }}
                    </div>
        @endif
        @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New Page</h3>
        </div>
        <div class="box-body">
          <div class="row">
           {{ Form::open(array('url' => 'admin/home','name' => 'page','files' => true)) }}
            <div class="col-md-12">
              <div class="form-group">
              {{ Form::label('title', 'Page Title') }}<em class="error">&nbsp;*</em>
              {{ Form::text('title',null, array('class' => 'form-control')) }}
              </div>
              <div class="form-group">
              {{ Form::label('banner', 'Banner Image') }}<em class="error">&nbsp;*</em>
              {{ Form::file('image',array('class' => 'form-control')) }}
              </div>
              <div class="form-group">
              {{ Form::label('content', 'Page Content') }}
              {{ Form::textarea('content') }}
              </div>
              <div class="form-group">
              {{ Form::submit('Submit',array('name' => 'submit','id' => 'submitpage')) }}
              </div>
            </div>
           {{ Form::close() }}
          </div>
        </div>
      </div>
    </section>
</div>
  @endsection
  
  
