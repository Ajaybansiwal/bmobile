<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>::Bmobile::</title>
<link href="{{ url('public/css/style.css') }}" rel="stylesheet">
<link href="{{ url('public/css/bootstrap.min.css') }}" type="text/css" rel="stylesheet" media="all">
<link href="{{ url('public/css/responsive.css') }}" type="text/css" rel="stylesheet" media="all">
<link href="{{ url('public/fonts/fonts.css') }}" type="text/css" rel="stylesheet" media="all">
<script src="{{ url('public/js/jquery-2.2.3.min.js') }}"></script>

<script>
  $(document).ready(function(){
     $('.menu-icon').click(function(){
	  $('div.menu ul').slideToggle();						   
     });
  })
</script>



</head>