<script>
	CKEDITOR.replace( 'content' );
</script>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <!--<b>Version</b>--> 
    </div>
    <strong>© 2017 bmobile. All rights reserved.</strong>
  </footer>