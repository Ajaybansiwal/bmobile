<?php

namespace App\Http\Controllers\front;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }
	
	/**
     * View index page .
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('layouts/home');
    }
}
