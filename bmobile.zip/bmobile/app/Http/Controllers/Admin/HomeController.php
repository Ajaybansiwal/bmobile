<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\Redirect;

use Session;

use View;

use File;

use App\page;

class HomeController extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
    public function __construct()
    {
        $this->middleware('auth');
    }
	/**
     * view homes listing.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$page = Page::all();
		$countpage = count($page);
		return View::make('admin.home.index',compact('page','countpage'));
	}
	/**
     * view the form for creating a new home.
     *
     * @return Response
     */
    public function create()
    {
        return view('admin.home.create');
    }
	/**
     * Store a homes with banner in storage.
     *
     * @return Response
     */
    public function store(Request $request)
    {
		$input = $request->all();
        $rules = array(
            'title'  			=> 'required|alpha|max:255',
            'image'      		=> 'required',
        );
        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('admin/home/create')
                ->withErrors($validator);
        } else {
			$image = Input::file('image');
			$filename  = time() . '.' . $image->getClientOriginalExtension();
			$path = public_path('images/banner/' . $filename);
			$image->move($path, $filename);
			
            $page = new page;
            $page->title   	= $input['title'];
            $page->image    = $filename;
            $page->content 	= $input['content'];
            $page->save();

            // redirect
            Session::flash('message', 'Successfully created home');
            return Redirect::to('admin/home/create');
        }
    }
	/**
     * View the home for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $page = Page::find($id);
        // show the edit form and pass the nerd
        return View::make('admin.home.edit',compact('page'));
    }
	/**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request,$id)
    {
		$input = $request->all();
		$rules = array(
            'title'  			=> 'required|alpha|max:255',
        );
		$validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('admin/home/' . $id . '/edit')
                ->withErrors($validator);
        }else {
			$oldimage = $input['oldimage'];
			$image = Input::file('image');
			if(empty($image))
			{
				$image = $oldimage;
			}
			else
			{
				$oldfilename = public_path().'/images/banner/'.$oldimage;
				File::deleteDirectory($oldfilename);
				$filename  = time() . '.' . $image->getClientOriginalExtension();
				$path = public_path('images/banner/' . $filename);
				$image->move($path, $filename);
				$image = $filename;
			}
			$page = Page::find($id);
			$page->title   	= $input['title'];
			$page->image    = $image;
			$page->content 	= $input['content'];
			$page->save();

			Session::flash('message', 'Successfully updated home');
			return Redirect::to('admin/home/' . $id . '/edit');
        } 
    }
	/**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        $page = Page::find($id);
        $page->delete();

        Session::flash('message', 'Successfully deleted the home');
        return Redirect::to('admin/home');
    }
}
