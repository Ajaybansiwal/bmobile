<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;


class AdminController extends Controller

{

    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function __construct()

    {

        $this->middleware('auth');

    }



    /**

     * View the admin panel.

     *

     * @return \Illuminate\Http\Response

     */


    public function index()

    {

        return view('admin/dashboard');
    }


	/**
     * Logout.
     *
     * @return \Response
     */
    public function logout()
    {
        \Auth::logout();    
		return Redirect::to('login');  
        //return $this->redirect('admin.index');
    }
}

