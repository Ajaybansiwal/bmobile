<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\Redirect;

use Session;

use View;

use File;

use App\User;

class RoleController extends Controller
{
    /**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
    public function __construct()
    {
        $this->middleware('auth');
    }
	/**
     * view users listing.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$user = User::all();
		$countuser = count($user);
		return View::make('admin.role.index',compact('user','countuser'));
	}
	/**
     * view the form for creating a new user.
     *
     * @return Response
     */
    public function create()
    {
        return view('admin.role.create');
    }
	/**
     * Store a user in storage.
     *
     * @return Response
     */
    public function store(Request $request)
    {
		$input = $request->all();
        $rules = array(
            'name'  			=> 'required|max:255',
            'email'      		=> 'required|email|max:255',
        );
        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('admin/role/create')
                ->withErrors($validator);
        } else {
			
            $user = new user;
            $user->name   		= $input['name'];
            $user->email    	= $input['email'];
            $user->password 	= bcrypt($input['password']);
            $user->save();

            // redirect
            Session::flash('message', 'Successfully created user');
            return Redirect::to('admin/role/create');
        }
    }
	/**
     * View the user for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $user = User::find($id);
        // show the edit form and pass the nerd
        return View::make('admin.role.edit',compact('user'));
    }
	/**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request,$id)
    {
		$input = $request->all();
		$rules = array(
            'name'  			=> 'required|max:255',
            'email'      		=> 'required|email|max:255',
        );
		$validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('admin/role/' . $id . '/edit')
                ->withErrors($validator);
        }else {
			$user = User::find($id);
			$user->name   		= $input['name'];
			$user->email    	= $input['email'];
			$user->save();

			Session::flash('message', 'Successfully updated user');
			return Redirect::to('admin/role/' . $id . '/edit');
        } 
    }
	/**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();

        Session::flash('message', 'Successfully deleted the user');
        return Redirect::to('admin/role');
    }
}
