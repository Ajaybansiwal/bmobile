<!doctype html>
<html>

<?php echo $__env->make('includes/front/head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<div class="wrapper">

   <?php echo $__env->make('includes/front/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
  
   <div class="featured">
  
    <div class="featured-img"><img src="<?php echo e(url('public/images/Home-Page.jpg')); ?>" alt=""></div>
    
    <div class="featured-content">
       <div class="featured-post"><a href="#"><h4>Products<span>you want</span></h4></a></div>
       <div class="featured-post"><a href="#"><h4>Pay Bills<span>services you need</span></h4></a></div>
       <div class="featured-post"><a href="#"><h4>promotions<span>for you</span></h4></a></div>
    </div>
  
  </div>
 
 
   <?php echo $__env->make('includes/front/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
 
  
  
</div>


</body>
</html>