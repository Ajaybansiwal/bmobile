<?php $__env->startSection('content'); ?>
<div class="login-box">
  <div class="login-logo">
    <b>Admin</b>&nbsp;Bmobile
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">

    <form role="form" method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo e(csrf_field()); ?>

      <div class="form-group has-feedback">
      <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Your Email" required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
      </div>
      <div class="form-group has-feedback">
        <input id="password" type="password" class="form-control" name="password" required placeholder="*******">
        <span class="glyphicon glyphicon-lock form-control-feedback fa fa-unlock-alt"></span>
        <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
      </div>
      <div class="row">
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    
  </div>
  <!-- /.login-box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>