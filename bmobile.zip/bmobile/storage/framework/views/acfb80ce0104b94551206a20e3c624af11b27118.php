<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
    <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('message')); ?>

                    </div>
        <?php endif; ?>
       <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit User</h3>
        </div>
        <div class="box-body">
          <div class="row">
           <?php echo e(Form::model($user, array('route' => array('role.update', $user->id), 'method' => 'PUT','name' => 'user'))); ?>

            <div class="col-md-12">
              <div class="form-group">
              <?php echo e(Form::label('name', 'Name')); ?>

              <?php echo e(Form::text('name',$user->name, array('class' => 'form-control'))); ?>

              </div>
              <div class="form-group">
              <?php echo e(Form::label('email', 'Email Id')); ?><em class="error">&nbsp;*</em>
              <?php echo e(Form::text('email',$user->email,array('class' => 'form-control'))); ?>

              </div>
              <div class="form-group">
              <?php echo e(Form::submit('Submit',array('name' => 'submit'))); ?>

              </div>
            </div>
           <?php echo e(Form::close()); ?>

          </div>
        </div>
      </div>
    </section>
</div>
  <?php $__env->stopSection(); ?>
  
  

<?php echo $__env->make('layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>