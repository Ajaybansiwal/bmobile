<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New Page</h3>
          <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
               <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="box-body">
          <div class="row">
           <?php echo e(Form::open(array('url' => 'page','name' => 'page','files' => true))); ?>

            <div class="col-md-12">
              <div class="form-group">
              <?php echo e(Form::label('title', 'Page Title')); ?>

              <?php echo e(Form::text('title',null, array('class' => 'form-control'))); ?>

              </div>
              <div class="form-group">
              <?php echo e(Form::label('banner', 'Banner Image')); ?>

              <?php echo e(Form::file('image',array('class' => 'form-control'))); ?>

              </div>
              <div class="form-group">
              <?php echo e(Form::label('content', 'Page Content')); ?>

              <?php echo e(Form::textarea('content')); ?>

              </div>
              <div class="form-group">
              <?php echo e(Form::submit('Submit',array('name' => 'submit'))); ?>

              </div>
            </div>
           <?php echo e(Form::close()); ?>

          </div>
        </div>
      </div>
    </section>
</div>
  <?php $__env->stopSection(); ?>
  
  

<?php echo $__env->make('layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>