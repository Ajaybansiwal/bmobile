<header class="header">
    <div class="container">
     
       <div class="brand"><a href="#"><img src="<?php echo e(url('public/images/logo.png')); ?>" ="brand"></a></div>
    
       <div class="header-right"> 
      
         <div class="menu">
          <a href="#" class="menu-icon"></a>
          <ul>
           <li class="mobile-search-top">
             <div class="search-box mobile-search">
              <div class="search-content"><input type="text" placeholder="Search"><input class="search-btn" type="button" value="Search"></div>
              <div class="business-link"><a href="#" class="business-link-txt">Business</a><a href="#" class="mybmobile-txt">MyBmobile</a></div>
             </div>
           </li>
           <li class="active"><a href="#">Home</a></li>                                                
           <li><a href="#">Help &amp; Support</a></li>
           <li><a href="#">Products</a></li>
           <li><a href="#">E-Top Up</a></li>
           <li><a href="#">Why Bmobile </a></li>
          </ul>
         </div>
         
         <div class="search-box desktop-search">
          <div class="search-content"><input type="text" placeholder="Search"><input class="search-btn" type="button" value="Search"></div>
          <div class="business-link"><a href="#" class="business-link-txt">Business</a><a href="#" class="mybmobile-txt">MyBmobile</a></div>
         </div>
         
        </div>
      
    </div>
  </header>