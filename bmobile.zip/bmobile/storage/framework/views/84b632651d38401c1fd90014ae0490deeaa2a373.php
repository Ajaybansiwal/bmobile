<!DOCTYPE html>
<html>
<?php echo $__env->make('includes/admin/head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php echo $__env->make('includes/admin/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php echo $__env->make('includes/admin/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  
  <?php echo $__env->yieldContent('content'); ?>
  <!-- /.content-wrapper -->
  
  <?php echo $__env->make('includes/admin/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
</body>
</html>
