<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>::Bmobile::</title>
<link href="<?php echo e(url('public/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('public/css/bootstrap.min.css')); ?>" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo e(url('public/css/responsive.css')); ?>" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo e(url('public/fonts/fonts.css')); ?>" type="text/css" rel="stylesheet" media="all">
<script src="<?php echo e(url('public/js/jquery-1.11.0.min.js')); ?>"></script>

<script>
  $(document).ready(function(){
     $('.menu-icon').click(function(){
	  $('div.menu ul').slideToggle();						   
     });
  })
</script>



</head>

<body>





<div class="wrapper">

   <?php echo $__env->make('front/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
  
   <div class="featured">
  
    <div class="featured-img"><img src="<?php echo e(url('public/images/Home-Page.jpg')); ?>" alt=""></div>
    
    <div class="featured-content">
       <div class="featured-post"><a href="#"><h4>Products<span>you want</span></h4></a></div>
       <div class="featured-post"><a href="#"><h4>Pay Bills<span>services you need</span></h4></a></div>
       <div class="featured-post"><a href="#"><h4>promotions<span>for you</span></h4></a></div>
    </div>
  
  </div>
 
 
   <?php echo $__env->make('front/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
 
  
  
</div>


</body>
</html>