<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
        <?php if(Session::has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('message')); ?>

                </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Pages</h3>
          <span style="margin-left:965px;"><a href="<?php echo e(url('admin/home/create')); ?>">Create New</a></span>
        </div>
        <div class="box-body">
          <div class="row">
			<div class="col-xs-12">
          <div class="box">
            <!--<div class="box-header">
              <h3 class="box-title">Responsive Hover Table</h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tr>
                  <th>Title</th>
                  <th>Image</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                <?php if($countpage==0): ?>
                <tr>
                    <td colspan="4">No Record Found.</td>
                </tr> 
                <?php else: ?>
                <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($pages->title); ?></td>
                  <td><img src="http://localhost/bmobile/public/images/banner/<?php echo e($pages->image); ?>/<?php echo e($pages->image); ?>" height="46px" width="50px"></td>
                  <?php if($pages->status==1): ?>
                  <td><span class="label label-success">Enable</span></td>
                  <?php else: ?>
                  <td><span class="label label-danger">Disable</span></td>
                  <?php endif; ?>
                  <td class="action">
                  <a href="<?php echo e(route('home.edit', $pages->id)); ?>"><button class="btn btn-sm filter-submit margin-bottom">Edit</button></a>	&nbsp;
                  <?php echo Form::open(['method' => 'DELETE','route' => ['home.destroy', $pages->id]]); ?>

                  <button onclick="return deletepage(this.value)" class="btn btn-sm  filter-submit margin-bottom">Delete</button>
                  <?php echo Form::close(); ?>

                  &nbsp;<!--<a href="<?php echo e(URL::to('page/' . $pages->id)); ?>"><button class="btn btn-sm  filter-submit margin-bottom">Status</button></a>&nbsp;<a href="<?php echo e(URL::to('page/' . $pages->id)); ?>"><button class="btn btn-sm  filter-submit margin-bottom">View</button></a>-->
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <?php endif; ?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>          
          </div>
        </div>
      </div>
    </section>
</div>
  <?php $__env->stopSection(); ?>
  
  

<?php echo $__env->make('layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>