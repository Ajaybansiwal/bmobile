<footer class="footer">
  
  <div class="back-top"><a href="#"><img src="<?php echo e(url('public/images/go-top.png')); ?>" alt=""></a></div> 
  
   <div class="container">
   
   <div class="copyright">&copy; 2017 bmobile. All rights reserved.</div>
   
   <div class="footer-menu">
    <ul>
      <li><a href="#">Home</a><span>·</span></li>
      <li><a href="#">Business</a><span>·</span></li>
      <li><a href="#">Help &amp; Support</a><span>·</span></li>
      <li><a href="#">Pay Bills</a><span>·</span></li>
      <li><a href="#">Contact</a></li>
    </ul>
   </div>
    
   </div>
 </footer>